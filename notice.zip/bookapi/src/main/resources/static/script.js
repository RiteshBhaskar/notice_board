const apiUrl = "http://localhost:8085/notices";
const notification = document.getElementById("notification");

let noticesData = [];

/* ---------- NOTIFICATION ---------- */
function showNotification(msg, type = "success") {
    notification.textContent = msg;
    notification.className = `notification ${type}`;
    notification.style.display = "block";
    setTimeout(() => notification.style.display = "none", 3000);
}

/* ---------- NAVIGATION ---------- */
function showSection(section) {
    document.getElementById("dashboard-menu").style.display = "none";

    ["add", "update", "delete", "view"].forEach(s => {
        document.getElementById(`${s}-section`).style.display =
            s === section ? "block" : "none";
    });

    if (section === "view") fetchNotices();
}

function backToDashboard() {
    document.getElementById("dashboard-menu").style.display = "block";
    ["add", "update", "delete", "view"].forEach(s => {
        document.getElementById(`${s}-section`).style.display = "none";
    });
}

/* ---------- ADD ---------- */
document.getElementById("addNoticeForm").addEventListener("submit", e => {
    e.preventDefault();

    const title = document.getElementById("addTitle").value;
    const description = document.getElementById("addDescription").value;

    fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description })
    })
        .then(() => {
            showNotification("Notice added successfully");
            e.target.reset();
        });
});

/* ---------- UPDATE ---------- */
function proceedUpdate() {
    const id = parseInt(document.getElementById("existingId").value);
    const notice = noticesData.find(n => n.id === id);

    if (!notice) {
        showNotification("Notice not found", "error");
        return;
    }

    document.getElementById("update-step1").style.display = "none";
    document.getElementById("update-step2").style.display = "block";

    document.getElementById("updateTitle").value = notice.title;
    document.getElementById("updateDescription").value = notice.description;

    document.getElementById("updateNoticeForm").dataset.id = id;
}

function backToUpdateStep1() {
    document.getElementById("update-step1").style.display = "block";
    document.getElementById("update-step2").style.display = "none";
}

document.getElementById("updateNoticeForm").addEventListener("submit", e => {
    e.preventDefault();

    const id = e.target.dataset.id;
    const title = document.getElementById("updateTitle").value;
    const description = document.getElementById("updateDescription").value;

    fetch(`${apiUrl}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description })
    })
        .then(() => {
            showNotification("Notice updated");
            backToUpdateStep1();
        });
});

/* ---------- DELETE ---------- */
document.getElementById("deleteNoticeForm").addEventListener("submit", e => {
    e.preventDefault();

    const id = document.getElementById("deleteId").value;

    fetch(`${apiUrl}/${id}`, { method: "DELETE" })
        .then(() => showNotification("Notice deleted"));
});

/* ---------- FETCH ---------- */
function fetchNotices() {
    fetch(apiUrl)
        .then(res => res.json())
        .then(data => {
            noticesData = data;
            renderNotices(data);
        });
}

function renderNotices(notices) {
    const tbody = document.getElementById("noticesTableBody");
    tbody.innerHTML = "";

    notices.forEach(n => {
        tbody.innerHTML += `
            <tr>
                <td>${n.id}</td>
                <td>${n.title}</td>
                <td>${n.description}</td>
                <td>
                    <button onclick="deleteNotice(${n.id})">Delete</button>
                </td>
            </tr>
        `;
    });
}

function deleteNotice(id) {
    fetch(`${apiUrl}/${id}`, { method: "DELETE" })
        .then(() => {
            showNotification("Notice deleted");
            fetchNotices();
        });
}
