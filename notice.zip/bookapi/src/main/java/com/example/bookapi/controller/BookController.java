package com.example.bookapi.controller;



import com.example.bookapi.model.Book;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@RestController
@RequestMapping("/books")
@CrossOrigin("*") // frontend ke liye IMPORTANT
public class BookController {

    List<Book> books = new ArrayList<>();

    // CREATE
    @PostMapping
    public String addBook(@RequestBody Book book) {
        books.add(book);
        return "Notice  Added Successfully";
    }

    // READ
    @GetMapping
    public List<Book> getBooks() {
        return books;
    }

    // UPDATE
    @PutMapping("/{id}")
    public String updateBook(@PathVariable int id, @RequestBody Book book) {
        for (Book b : books) {
            if (b.getId() == id) {
                b.setTitle(book.getTitle());
                b.setAuthor(book.getAuthor());
                return "Notice Updated";
            }
        }
        return "Notice Not Found";
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable int id) {
        books.removeIf(b -> b.getId() == id);
        return "Notice Deleted";
    }
}

